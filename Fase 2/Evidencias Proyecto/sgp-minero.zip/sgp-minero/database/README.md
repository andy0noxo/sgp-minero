# PostgreSQL y persistencia

PostgreSQL es un servicio independiente del backend y del frontend. En
desarrollo se ejecuta mediante el servicio `db` (`postgres:15-alpine`) de
[`docker-compose.yml`](../docker-compose.yml); en producción puede reemplazarse
por PostgreSQL administrado, como Neon (mediante `DATABASE_URL` con SSL), sin
cambiar el dominio del backend.

## Fuente única del esquema

El esquema oficial pertenece a Django y se versiona en
[`backend/core/migrations/`](../backend/core/migrations/) (`0001_initial` a
`0005_maestro_personas_faena`). No se crean tablas duplicadas mediante SQL
manual: esto evita que el esquema de PostgreSQL se desincronice del ORM, las
pruebas y el despliegue.

La carpeta `database` se conserva como frontera de infraestructura para:

- documentar la operación y persistencia de PostgreSQL;
- describir el modelo físico híbrido (relacional + documental `JSONB`);
- centralizar instrucciones de respaldo, restauración o verificación operativa.

La inicialización de roles y usuarios demo pertenece al backend y se ejecuta
mediante `seed_demo_data` cuando `SEED_DEMO_DATA=True` (solo permitido con
`DJANGO_DEBUG=True`); no se deben crear usuarios ni credenciales desde scripts
SQL. Los scripts operativos futuros no deben contener credenciales, datos reales
ni definiciones de tablas que ya pertenezcan a las migraciones.

## Modelo de datos híbrido implementado (6 entidades)

El modelo físico materializado por las migraciones de
[`backend/core/models.py`](../backend/core/models.py) combina integridad
relacional estricta con flexibilidad documental `JSONB`:

| Modelo Django | Tabla en PostgreSQL | PK | Rol y Reglas de Integridad / Seguridad |
| --- | --- | --- | --- |
| `Rol` | `core_rol` | `BigAutoField` | Catálogo paramétrico RBAC (`Administrador`, `Cargador`, `Consultor`). |
| `Usuario` | `core_usuario` | `UUID` | Cuentas corporativas con `rut` único indexado, `email_corporativo` único, hash `Argon2`, `rol_id` (`PROTECT`) y campos anti-fuerza bruta (`failed_login_attempts`, `locked_until`). |
| `Maestro_Personas` | `core_maestro_personas` | `UUID` | Nómina oficial de validación interna (`600` trabajadores únicos en el seed y en `00_Maestro_Personas_Administrador_600_trabajadores.xlsx`): `rut` único indexado, `nombre_completo`, **`faena`** (dimensión operacional obligatoria), `centro_costo` (imputación contable) y `estado_habilitacion` (`450 Habilitados` / `150 Inhabilitados`). |
| `LoteCarga` | `lote_carga` | `UUID` | Cabecera transaccional de cada archivo procesado por un `Cargador` (`PROTECT`), totales de filas y `detalle_errores` (`JSONB` libre de PII). |
| `RegistroViaje` | `registro_viaje` | `UUID` | Entidad híbrida central asociada a `Usuario` y `LoteCarga` (`PROTECT`), con `fila_origen`, `estado_validacion`, índices compuestos `(fecha_procesamiento, estado_validacion)` y `(cargador, fecha_procesamiento)`, y columna **`payload_datos` (`JSONB`)** donde el RUT y el Nombre se guardan exclusivamente cifrados con `Fernet` (`AES-128-CBC + HMAC-SHA256`), acompañados de `faena`, `centro_costo` y `estado_habilitacion` inyectados desde `Maestro_Personas`, `fecha_vuelo` + `tipo_fecha_vuelo` (5 modalidades mineras), las 6 columnas variables logísticas (`origen`, `destino`, `aerolinea`, `turno`, `telefono_contacto`, `anotaciones`) y las columnas dinámicas adicionales del Excel. |
| `RegistroAuditoria` | `registro_auditoria` | `UUID` | Bitácora inmutable de acciones críticas (`LOGIN_EXITOSO`, `LOGIN_FALLIDO`, `CUENTA_BLOQUEADA`, `LOGIN_BLOQUEADO`, `PROCESAR_CARGA_VIAJES`, `IMPORTAR_MAESTRO_PERSONAS`, `CREAR_USUARIO`, `ACTUALIZAR_USUARIO`, `EXPORTAR_AUDITORIA`) con `usuario_id` (`PROTECT`, `null=True`) y `metadata` en `JSONB` sin PII. |

El diagrama gráfico actualizado del modelo relacional híbrido de 6 entidades se encuentra disponible en el documento de diseño técnico (`Fase 2/Evidencias Proyecto/DOCUMENTACIÓN ÁGIL - FASE 1_ SGP-MINERO.docx`, Sección Diagramas de Arquitectura y Base de Datos).

## Creación local con Docker

Desde la raíz del repositorio:

```powershell
docker compose up --build -d
```

En el primer arranque, PostgreSQL crea automáticamente la base definida por
`DB_NAME`. El backend espera el healthcheck del servicio `db` (`pg_isready`) y
ejecuta `python manage.py migrate --noinput` antes de iniciar Django.

La base queda disponible en `localhost:5432` con las credenciales definidas en
`.env`. Antes del primer arranque se debe copiar `.env.example` a `.env` y
completar `DB_PASSWORD`, `DJANGO_SECRET_KEY` y `AES_SECRET_KEY` (ya que
`docker-compose.yml` y `settings.py` validan su presencia al iniciar).

Comandos de verificación:

```powershell
docker compose ps
docker compose logs -f db
docker compose exec backend python manage.py showmigrations
docker compose exec backend python manage.py check
docker compose exec backend pytest
docker compose exec db pg_isready -U usuario_local -d sgp_minero_db
curl.exe http://localhost:8000/api/v1/health/
```

Para detener los servicios sin eliminar los datos:

```powershell
docker compose down
```

`docker compose down -v` elimina el volumen `pgdata` y los datos locales;
solo debe utilizarse en un entorno descartable.

## Persistencia y datos

El volumen Docker `pgdata` mantiene los datos entre reinicios. No debe
eliminarse en un entorno con datos que se quieran conservar. Para reiniciar
solamente un entorno local descartable se puede eliminar explícitamente ese
volumen y volver a levantar Compose.

Las credenciales, `AES_SECRET_KEY`, archivos `.env` y datos reales no deben
versionarse. La PII de los viajes se cifra con `Fernet` antes de persistirse en
el campo `JSONB` de `RegistroViaje` (`registro_viaje.payload_datos`), cumpliendo
con la Ley N° 19.628.
