const API_BASE_URL = (import.meta.env.VITE_API_URL || '/api/v1').replace(/\/$/, '');

let accessToken = null;

export function setAccessToken(token) {
  accessToken = token;
}

export function clearAccessToken() {
  accessToken = null;
}

export function decodeJwtPayload(token = accessToken) {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  try {
    const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const padded = base64.padEnd(base64.length + ((4 - (base64.length % 4)) % 4), '=');
    return JSON.parse(atob(padded));
  } catch {
    return null;
  }
}

export function getUserFromToken(token = accessToken, fallbackUser = null) {
  const claims = decodeJwtPayload(token);
  if (!claims) return fallbackUser;
  return {
    ...fallbackUser,
    id: fallbackUser?.id || claims.user_id,
    rut: fallbackUser?.rut || claims.rut,
    email_corporativo: fallbackUser?.email_corporativo || claims.email,
    role: claims.role || fallbackUser?.role || null,
  };
}

async function request(path, options = {}, canRefresh = true) {
  const headers = new Headers(options.headers);
  if (accessToken) headers.set('Authorization', `Bearer ${accessToken}`);

  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers,
    credentials: 'include',
  });
  const payload = await response.json().catch(() => ({}));

  if (response.status === 401 && canRefresh && path !== '/auth/refresh/') {
    try {
      const refreshed = await request('/auth/refresh/', { method: 'POST' }, false);
      setAccessToken(refreshed.data.access);
      return request(path, options, false);
    } catch {
      clearAccessToken();
    }
  }

  if (!response.ok) {
    const error = new Error(payload.error?.message || 'No fue posible completar la solicitud.');
    error.status = response.status;
    error.code = payload.error?.code;
    error.details = payload.error?.details;
    throw error;
  }
  return payload;
}

export function login(identifier, password) {
  return request('/auth/login/', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier, password }),
  });
}

export function refreshToken() {
  return request('/auth/refresh/', { method: 'POST' });
}

export function logout() {
  return request('/auth/logout/', { method: 'POST' }, false);
}

export function getCurrentUser() {
  return request('/auth/me/');
}

export function getUploadHeaders(file) {
  const formData = new FormData();
  formData.append('file', file);
  return request('/uploads/headers/', { method: 'POST', body: formData });
}

export function processUpload(file, mapping) {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('mapping', JSON.stringify(mapping));
  return request('/uploads/process/', { method: 'POST', body: formData });
}

export function getUploadHistory(filters = {}) {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value) params.set(key, value);
  });
  return request(`/uploads/history/?${params.toString()}`);
}

export function getUploadDetail(batchId) {
  return request(`/uploads/history/${batchId}/`);
}

export function importMasterPeople(file) {
  const formData = new FormData();
  formData.append('file', file);
  return request('/master-persons/import/', { method: 'POST', body: formData });
}

export function getMasterPeople(filters = {}) {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value) params.set(key, value);
  });
  return request(`/master-persons/?${params.toString()}`);
}

export function getDashboardRecords(filters = {}) {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value) params.set(key, value);
  });
  return request(`/dashboard/records/?${params.toString()}`);
}

export function getUsers(filters = {}) {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value) params.set(key, value);
  });
  return request(`/users/?${params.toString()}`);
}

export function createUser(userData) {
  return request('/users/', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(userData),
  });
}

export function updateUser(userId, data) {
  return request(`/users/${userId}/`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
}

export function getAuditLogs(filters = {}) {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') {
      params.set(key, value);
    }
  });
  return request(`/audit-logs/?${params.toString()}`);
}

export async function downloadAuditCsv(filters = {}) {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') {
      params.set(key, value);
    }
  });
  params.set('export', 'csv');
  const headers = {};
  if (accessToken) headers['Authorization'] = `Bearer ${accessToken}`;
  const response = await fetch(`${API_BASE_URL}/audit-logs/?${params.toString()}`, {
    method: 'GET',
    headers,
  });
  if (!response.ok) {
    throw new Error('Error al descargar el archivo CSV de auditoría.');
  }
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `auditoria-${new Date().toISOString().slice(0, 10)}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}
