import json
from datetime import date

from django.conf import settings
from django.core.paginator import Paginator
from django.db import OperationalError, connection
from django.db.models import Q
from django.http import HttpResponse
from rest_framework import status
from rest_framework.exceptions import NotFound
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenRefreshView

from .models import Maestro_Personas, RegistroAuditoria, RegistroViaje
from .authentication import LoginSerializer
from .permissions import IsAdministrador, IsCargador, IsConsultor
from .serializers import (
    AuditLogSerializer,
    AuthUserSerializer,
    UserManagementSerializer,
)
from .services.api_errors import UploadValidationError
from .services.audit_service import build_audit_csv, list_audit_logs
from .services.excel_reader import FileProcessingError, inspect_excel
from .services.mapper import MapperValidationError
from .services.master_person_importer import MasterImportError, import_master_people
from .services.travel_processor import process_travel_file
from .services.dashboard import get_dashboard_records
from .services.upload_history import get_upload_detail, get_upload_history
from .services.user_management import (
    create_user_with_audit,
    list_users,
    update_user_with_audit,
)


class LoginView(APIView):
    permission_classes = (AllowAny,)

    def post(self, request):
        serializer = LoginSerializer(
            data=request.data,
            context={"request": request},
        )
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        response = Response(
            {
                "data": {
                    "access": data["access"],
                    "user": data["user"],
                },
                "message": "Autenticación exitosa.",
            },
            status=status.HTTP_200_OK,
        )
        response.set_cookie(
            settings.REFRESH_TOKEN_COOKIE_NAME,
            data["refresh"],
            httponly=True,
            secure=settings.REFRESH_TOKEN_COOKIE_SECURE,
            samesite=settings.REFRESH_TOKEN_COOKIE_SAMESITE,
            path=settings.REFRESH_TOKEN_COOKIE_PATH,
            max_age=int(settings.SIMPLE_JWT["REFRESH_TOKEN_LIFETIME"].total_seconds()),
        )
        return response


class RefreshTokenView(TokenRefreshView):
    permission_classes = (AllowAny,)

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(
            data={
                "refresh": request.COOKIES.get(settings.REFRESH_TOKEN_COOKIE_NAME),
            }
        )
        serializer.is_valid(raise_exception=True)
        return Response(
            {"data": {"access": serializer.validated_data["access"]}},
            status=status.HTTP_200_OK,
        )


class LogoutView(APIView):
    permission_classes = (AllowAny,)

    def post(self, request):
        response = Response(
            {"message": "Sesión cerrada."},
            status=status.HTTP_200_OK,
        )
        response.delete_cookie(
            settings.REFRESH_TOKEN_COOKIE_NAME,
            path=settings.REFRESH_TOKEN_COOKIE_PATH,
        )
        return response


class CurrentUserView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        return Response(
            {"data": AuthUserSerializer(request.user).data},
            status=status.HTTP_200_OK,
        )


class HealthView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        try:
            connection.ensure_connection()
        except OperationalError:
            return Response(
                {"status": "unhealthy", "database": "unavailable"},
                status=status.HTTP_503_SERVICE_UNAVAILABLE,
            )
        return Response(
            {"status": "ok", "database": "ok"},
            status=status.HTTP_200_OK,
        )


class UploadHeadersView(APIView):
    permission_classes = (IsCargador,)

    def post(self, request):
        uploaded_file = request.FILES.get("file")
        if uploaded_file is None:
            raise UploadValidationError(
                "INVALID_FILE", "Debe enviar un archivo en el campo file."
            )
        try:
            info = inspect_excel(uploaded_file)
        except FileProcessingError as exc:
            raise UploadValidationError("INVALID_FILE", str(exc)) from exc
        return Response(
            {"data": info},
            status=status.HTTP_200_OK,
        )


class UploadProcessView(APIView):
    permission_classes = (IsCargador,)

    def post(self, request):
        uploaded_file = request.FILES.get("file")
        if uploaded_file is None:
            raise UploadValidationError(
                "INVALID_FILE", "Debe enviar un archivo en el campo file."
            )
        raw_mapping = request.data.get("mapping")
        if not raw_mapping:
            raise UploadValidationError(
                "MISSING_MAPPER", "Debe enviar el mapeo de columnas."
            )
        try:
            mapping = (
                json.loads(raw_mapping) if isinstance(raw_mapping, str) else raw_mapping
            )
            result = process_travel_file(uploaded_file, mapping, request.user)
        except (
            json.JSONDecodeError,
            FileProcessingError,
            MapperValidationError,
        ) as exc:
            raise UploadValidationError("INVALID_UPLOAD", str(exc)) from exc
        response_status = (
            status.HTTP_207_MULTI_STATUS
            if result["total_errores"]
            else status.HTTP_200_OK
        )
        return Response({"data": result}, status=response_status)


class UploadHistoryView(APIView):
    permission_classes = (IsCargador,)

    def get(self, request):
        try:
            page = max(int(request.query_params.get("page", 1)), 1)
            page_size = max(int(request.query_params.get("page_size", 25)), 1)
        except ValueError as exc:
            raise UploadValidationError(
                "INVALID_PAGINATION",
                "page y page_size deben ser números enteros.",
            ) from exc
        return Response(
            {"data": get_upload_history(request.user, page, page_size)},
            status=status.HTTP_200_OK,
        )


class UploadDetailView(APIView):
    permission_classes = (IsCargador,)

    def get(self, request, batch_id):
        data = get_upload_detail(request.user, batch_id)
        if data is None:
            raise NotFound("La carga solicitada no existe.")
        return Response({"data": data}, status=status.HTTP_200_OK)


class MasterPersonImportView(APIView):
    permission_classes = (IsAdministrador,)

    def post(self, request):
        uploaded_file = request.FILES.get("file")
        if uploaded_file is None:
            raise UploadValidationError(
                "INVALID_FILE",
                "Debe enviar un archivo en el campo file.",
            )
        try:
            result = import_master_people(uploaded_file, request.user)
        except (FileProcessingError, MasterImportError) as exc:
            raise UploadValidationError("INVALID_MASTER_FILE", str(exc)) from exc
        response_status = (
            status.HTTP_207_MULTI_STATUS
            if result["total_errores"]
            else status.HTTP_200_OK
        )
        return Response({"data": result}, status=response_status)


class MasterPersonListView(APIView):
    permission_classes = (IsAdministrador,)

    def get(self, request):
        try:
            page_number = max(int(request.query_params.get("page", 1)), 1)
            page_size = min(max(int(request.query_params.get("page_size", 25)), 1), 100)
        except ValueError as exc:
            raise UploadValidationError(
                "INVALID_PAGINATION",
                "page y page_size deben ser números enteros.",
            ) from exc

        queryset = Maestro_Personas.objects.all().order_by("nombre_completo")
        faena = request.query_params.get("faena")
        search = request.query_params.get("search")
        estado = request.query_params.get("estado")
        if faena:
            queryset = queryset.filter(faena__iexact=faena)
        if search:
            queryset = queryset.filter(
                Q(rut__icontains=search) | Q(nombre_completo__icontains=search)
            )
        if estado in {"habilitado", "inhabilitado"}:
            queryset = queryset.filter(estado_habilitacion=estado == "habilitado")
        elif estado:
            raise UploadValidationError(
                "INVALID_FILTER",
                "estado debe ser habilitado o inhabilitado.",
            )

        paginator = Paginator(queryset, page_size)
        page = paginator.get_page(page_number)
        return Response(
            {
                "data": {
                    "results": [
                        {
                            "id": str(person.id),
                            "rut": person.rut,
                            "nombre_completo": person.nombre_completo,
                            "faena": person.faena,
                            "centro_costo": person.centro_costo,
                            "estado_habilitacion": person.estado_habilitacion,
                        }
                        for person in page.object_list
                    ],
                    "pagination": {
                        "page": page.number,
                        "page_size": page.paginator.per_page,
                        "total": paginator.count,
                        "pages": paginator.num_pages,
                    },
                },
            }
        )


class DashboardRecordsView(APIView):
    permission_classes = (IsConsultor,)

    def get(self, request):
        filters = {
            "from": request.query_params.get("from"),
            "to": request.query_params.get("to"),
            "faena": request.query_params.get("faena"),
            "centro_costo": request.query_params.get("centro_costo"),
            "estado": request.query_params.get("estado"),
        }
        try:
            filters["page"] = max(int(request.query_params.get("page", 1)), 1)
            filters["page_size"] = max(
                int(request.query_params.get("page_size", 25)), 1
            )
        except ValueError as exc:
            raise UploadValidationError(
                "INVALID_FILTER",
                "page y page_size deben ser números enteros.",
            ) from exc
        if filters["from"] and filters["to"] and filters["from"] > filters["to"]:
            raise UploadValidationError(
                "INVALID_FILTER",
                "La fecha inicial no puede ser posterior a la fecha final.",
            )
        for key in ("from", "to"):
            if filters[key]:
                try:
                    date.fromisoformat(filters[key])
                except ValueError as exc:
                    raise UploadValidationError(
                        "INVALID_FILTER",
                        f"{key} debe usar el formato YYYY-MM-DD.",
                    ) from exc
        if filters["estado"] and filters["estado"] not in {
            choice.value for choice in RegistroViaje.EstadoValidacion
        }:
            raise UploadValidationError(
                "INVALID_FILTER",
                "estado debe ser APROBADO o RECHAZADO.",
            )
        try:
            data = get_dashboard_records(filters)
        except ValueError as exc:
            raise UploadValidationError("INVALID_FILTER", str(exc)) from exc
        return Response({"data": data}, status=status.HTTP_200_OK)


class UserListCreateView(APIView):
    permission_classes = (IsAdministrador,)

    def get(self, request):
        filters = {
            "search": request.query_params.get("search"),
            "role": request.query_params.get("role") or request.query_params.get("rol"),
            "estado": request.query_params.get("estado")
            or request.query_params.get("status"),
        }
        data = list_users(filters)
        serialized_users = UserManagementSerializer(data["users"], many=True).data
        return Response(
            {
                "data": {
                    "results": serialized_users,
                    "counts": data["counts"],
                }
            },
            status=status.HTTP_200_OK,
        )

    def post(self, request):
        new_user = create_user_with_audit(request.data, request.user)
        return Response(
            {
                "data": UserManagementSerializer(new_user).data,
                "message": "Usuario creado exitosamente.",
            },
            status=status.HTTP_201_CREATED,
        )


class UserDetailView(APIView):
    permission_classes = (IsAdministrador,)

    def patch(self, request, user_id):
        updated_user = update_user_with_audit(user_id, request.data, request.user)
        return Response(
            {
                "data": UserManagementSerializer(updated_user).data,
                "message": "Usuario actualizado exitosamente.",
            },
            status=status.HTTP_200_OK,
        )


class AuditLogListView(APIView):
    permission_classes = (IsAdministrador,)

    def get(self, request):
        filters = {
            "search": request.query_params.get("search"),
            "modulo": (
                request.query_params.get("modulo") or request.query_params.get("module")
            ),
            "resultado": (
                request.query_params.get("resultado")
                or request.query_params.get("status")
            ),
            "from": (
                request.query_params.get("from")
                or request.query_params.get("fecha_desde")
            ),
            "to": (
                request.query_params.get("to")
                or request.query_params.get("fecha_hasta")
            ),
            "page": request.query_params.get("page", 1),
            "page_size": request.query_params.get("page_size", 25),
        }
        is_csv = (
            request.query_params.get("format") == "csv"
            or request.query_params.get("export") == "csv"
        )

        if is_csv:
            filters["page"] = 1
            filters["page_size"] = 5000
            data = list_audit_logs(filters)
            serialized = AuditLogSerializer(data["results"], many=True).data
            csv_content = build_audit_csv(serialized)

            RegistroAuditoria.objects.create(
                usuario=request.user if request.user.is_authenticated else None,
                accion="EXPORTAR_AUDITORIA",
                modulo="AUDITORIA",
                resultado=RegistroAuditoria.Resultado.EXITOSO,
                metadata={
                    "total_exportados": len(serialized),
                    "formato": "CSV",
                },
            )

            response = HttpResponse(csv_content, content_type="text/csv; charset=utf-8")
            response["Content-Disposition"] = (
                'attachment; filename="pistas_auditoria.csv"'
            )
            return response

        data = list_audit_logs(filters)
        serialized_logs = AuditLogSerializer(data["results"], many=True).data
        return Response(
            {
                "data": {
                    "results": serialized_logs,
                    "pagination": data["pagination"],
                    "counts": data["counts"],
                }
            },
            status=status.HTTP_200_OK,
        )
